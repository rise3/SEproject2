create
    definer = root@localhost procedure agreeApply(IN s int, IN aid1 int)
BEGIN
      declare s1 char(32);
      declare wid1 int;
      set s1 = (select request from apply where aid=aid1);
      set wid1 = (select wid from apply where aid=aid1);
      if '申请出诊'=s1 then
        update workday set state='预约',nsnum=s where wid=wid1;
      end if;
      if '申请停诊'=s1 then
        update workday set state='停诊',nsnum=0 where wid=wid1;
      end if;
      update apply set state='同意' where aid=aid1;
    END;

