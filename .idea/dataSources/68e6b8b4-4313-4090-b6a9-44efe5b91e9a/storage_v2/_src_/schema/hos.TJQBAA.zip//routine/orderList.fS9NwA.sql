create
    definer = root@localhost procedure orderList(IN pid int)
BEGIN
      select recode.rid,recode.pid,recode.wid,recode.did,recode.serialnumber,recode.visitdate,recode.visitnoon,recode.visittime,recode.ordertime,recode.state,
      doctor.dname,doctor.office,doctor.room,doctor.picpath,doctor.fee
      from recode,doctor
      where recode.pid=pid  and doctor.did=recode.did
      order by recode.ordertime desc;
    END;

