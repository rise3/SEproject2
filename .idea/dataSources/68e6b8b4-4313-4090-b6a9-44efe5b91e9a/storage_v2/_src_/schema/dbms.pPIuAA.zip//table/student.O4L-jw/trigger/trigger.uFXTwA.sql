create definer = root@localhost trigger `trigger`
    before delete
    on student
    for each row
BEGIN
    DELETE FROM grade WHERE sid = OLD.sid;
END;

