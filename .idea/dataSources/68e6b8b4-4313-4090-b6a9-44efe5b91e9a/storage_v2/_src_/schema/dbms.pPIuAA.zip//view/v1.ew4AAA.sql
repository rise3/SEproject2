create definer = root@localhost view v1 as
select `dbms`.`student`.`sid`         AS `sid`,
       `dbms`.`student`.`sname`       AS `sname`,
       `dbms`.`student`.`sclass`      AS `sclass`,
       `dbms`.`student`.`sdepartment` AS `sdepartment`,
       `dbms`.`student`.`sdormitory`  AS `sdormitory`
from `dbms`.`student`
where (`dbms`.`student`.`sdepartment` = 2);

