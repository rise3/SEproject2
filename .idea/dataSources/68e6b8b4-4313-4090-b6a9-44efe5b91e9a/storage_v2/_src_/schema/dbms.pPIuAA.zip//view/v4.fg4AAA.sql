create definer = root@localhost view v4 as
select `dbms`.`grade`.`cid` AS `cid`, avg(`dbms`.`grade`.`labscore`) AS `avg(labscore)`
from `dbms`.`grade`
group by `dbms`.`grade`.`cid`
having (avg(`dbms`.`grade`.`labscore`) > 85);

