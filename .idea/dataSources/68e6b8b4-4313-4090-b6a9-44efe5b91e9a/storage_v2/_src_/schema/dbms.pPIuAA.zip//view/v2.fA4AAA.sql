create definer = root@localhost view v2 as
select `dbms`.`student`.`sid`         AS `sid`,
       `dbms`.`student`.`sname`       AS `sname`,
       `dbms`.`student`.`sclass`      AS `sclass`,
       `dbms`.`student`.`sdepartment` AS `sdepartment`,
       `dbms`.`student`.`sdormitory`  AS `sdormitory`,
       `dbms`.`grade`.`cid`           AS `cid`,
       `dbms`.`grade`.`score`         AS `score`,
       `dbms`.`grade`.`labscore`      AS `labscore`
from (`dbms`.`student` join `dbms`.`grade`)
where ((`dbms`.`student`.`sdepartment` = 3) and (`dbms`.`student`.`sid` = `dbms`.`grade`.`sid`));

