create definer = root@localhost view v3 as
select distinct `dbms`.`course`.`cname`  AS `cname`,
                `dbms`.`student`.`sid`   AS `sid`,
                `dbms`.`student`.`sname` AS `sname`
from ((`dbms`.`course` join `dbms`.`student`) join `dbms`.`grade`)
where (((`dbms`.`course`.`cid` = `dbms`.`grade`.`cid`) and (`dbms`.`student`.`sid` = `dbms`.`grade`.`sid`) and
        (`dbms`.`course`.`cid` = 6)) or (`dbms`.`course`.`cname`, `dbms`.`student`.`sid`, `dbms`.`student`.`sname`) in
                                        (select distinct `dbms`.`course`.`cname`,
                                                         `dbms`.`student`.`sid`,
                                                         `dbms`.`student`.`sname`
                                         from ((`dbms`.`course` join `dbms`.`student`) join `dbms`.`grade`)
                                         where ((`dbms`.`course`.`cid` = `dbms`.`grade`.`cid`) and
                                                (`dbms`.`student`.`sid` = `dbms`.`grade`.`sid`) and
                                                (`dbms`.`course`.`cid` = 7))));

