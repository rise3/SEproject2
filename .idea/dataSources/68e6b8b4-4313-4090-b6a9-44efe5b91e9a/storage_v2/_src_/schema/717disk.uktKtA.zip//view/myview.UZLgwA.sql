create definer = root@localhost view myview as
(
select `717disk`.`user_file`.`u_id`    AS `u_id`,
       `717disk`.`file`.`f_id`         AS `f_id`,
       `717disk`.`file`.`f_name`       AS `f_name`,
       `717disk`.`file`.`f_size`       AS `f_size`,
       `717disk`.`file`.`f_uploadtime` AS `f_uploadtime`,
       `717disk`.`file`.`f_path`       AS `f_path`,
       `717disk`.`file`.`f_MD5`        AS `f_MD5`,
       `717disk`.`file`.`f_countl`     AS `f_countl`
from (`717disk`.`user_file` join `717disk`.`file` on ((`717disk`.`user_file`.`f_id` = `717disk`.`file`.`f_id`))));

